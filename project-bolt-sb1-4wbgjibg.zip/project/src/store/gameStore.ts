import { create } from 'zustand';
import { GameState, Car, Track, LeaderboardEntry } from '../types';
import { cars } from '../data/cars';
import { tracks } from '../data/tracks';

interface GameStore extends GameState {
  setScreen: (screen: GameState['screen']) => void;
  selectCar: (car: Car) => void;
  selectTrack: (track: Track) => void;
  startGame: () => void;
  pauseGame: () => void;
  resumeGame: () => void;
  endGame: () => void;
  updateSpeed: (speed: number) => void;
  updateLap: (lap: number) => void;
  updateTime: (time: number) => void;
  updateBestLap: (time: number) => void;
  updatePosition: (position: number) => void;
  toggleMute: () => void;
  leaderboard: LeaderboardEntry[];
  addLeaderboardEntry: (entry: LeaderboardEntry) => void;
}

// Mock leaderboard data
const mockLeaderboard: LeaderboardEntry[] = [
  { playerName: 'SpeedRacer', car: 'Thunder', track: 'Coastal Circuit', time: 124.35, date: '2025-03-15' },
  { playerName: 'DriftKing', car: 'Phantom', track: 'Mountain Pass', time: 145.82, date: '2025-03-14' },
  { playerName: 'RoadWarrior', car: 'Vortex', track: 'Urban Speedway', time: 167.21, date: '2025-03-12' },
];

export const useGameStore = create<GameStore>((set) => ({
  screen: 'menu',
  selectedCar: null,
  selectedTrack: null,
  isPlaying: false,
  currentLap: 0,
  totalLaps: 3,
  raceTime: 0,
  bestLap: 0,
  position: 0,
  speed: 0,
  isMuted: false,
  leaderboard: mockLeaderboard,
  
  setScreen: (screen) => set({ screen }),
  
  selectCar: (car) => set({ selectedCar: car }),
  
  selectTrack: (track) => set({ selectedTrack: track }),
  
  startGame: () => set({ 
    isPlaying: true, 
    screen: 'game',
    currentLap: 1,
    raceTime: 0,
    bestLap: 0
  }),
  
  pauseGame: () => set({ isPlaying: false, screen: 'pause' }),
  
  resumeGame: () => set({ isPlaying: true, screen: 'game' }),
  
  endGame: () => set({ 
    isPlaying: false, 
    screen: 'leaderboard',
    currentLap: 0,
    raceTime: 0
  }),
  
  updateSpeed: (speed) => set({ speed }),
  
  updateLap: (lap) => set({ currentLap: lap }),
  
  updateTime: (time) => set({ raceTime: time }),
  
  updateBestLap: (time) => set({ bestLap: time }),
  
  updatePosition: (position) => set({ position }),
  
  toggleMute: () => set((state) => ({ isMuted: !state.isMuted })),
  
  addLeaderboardEntry: (entry) => set((state) => ({ 
    leaderboard: [...state.leaderboard, entry].sort((a, b) => a.time - b.time) 
  }))
}));