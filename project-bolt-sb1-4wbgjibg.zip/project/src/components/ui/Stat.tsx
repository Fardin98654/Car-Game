import React from 'react';

interface StatProps {
  label: string;
  value: number | string;
  icon?: React.ReactNode;
  max?: number;
  color?: string;
}

const Stat: React.FC<StatProps> = ({
  label,
  value,
  icon,
  max = 100,
  color = 'indigo'
}) => {
  const numericValue = typeof value === 'number' ? value : 0;
  const percentage = max ? (numericValue / max) * 100 : 0;
  
  const colorVariants: Record<string, string> = {
    indigo: 'bg-indigo-500',
    purple: 'bg-purple-500',
    pink: 'bg-pink-500',
    blue: 'bg-blue-500',
    red: 'bg-red-500',
    green: 'bg-green-500',
    yellow: 'bg-yellow-500'
  };
  
  const bgColor = colorVariants[color] || colorVariants.indigo;
  
  return (
    <div className="flex flex-col space-y-1">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          {icon && <span className="text-gray-400">{icon}</span>}
          <span className="text-xs font-medium text-gray-400">{label}</span>
        </div>
        <span className="text-xs font-bold text-white">{value}</span>
      </div>
      {max && (
        <div className="w-full h-1 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className={`h-full ${bgColor} transition-all duration-500 ease-out`}
            style={{ width: `${percentage}%` }}
          ></div>
        </div>
      )}
    </div>
  );
};

export default Stat;