import { Car } from '../types';

export const cars: Car[] = [
  {
    id: 'car-1',
    name: 'Thunder',
    model: 'Sport GT',
    speed: 95,
    acceleration: 90,
    handling: 80,
    color: '#ff4d4d',
    thumbnail: 'https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'car-2',
    name: 'Phantom',
    model: 'Stealth X',
    speed: 85,
    acceleration: 95,
    handling: 90,
    color: '#2c3e50',
    thumbnail: 'https://images.pexels.com/photos/3136673/pexels-photo-3136673.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'car-3',
    name: 'Vortex',
    model: 'Cyclone R',
    speed: 90,
    acceleration: 85,
    handling: 95,
    color: '#3498db',
    thumbnail: 'https://images.pexels.com/photos/2127733/pexels-photo-2127733.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: 'car-4',
    name: 'Blaze',
    model: 'Inferno GT',
    speed: 100,
    acceleration: 95,
    handling: 75,
    color: '#f39c12',
    thumbnail: 'https://images.pexels.com/photos/3972755/pexels-photo-3972755.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];