import React, { useState } from 'react';
import { ArrowLeft, MapPin, Thermometer, Map as RoadMap } from 'lucide-react';
import { useGameStore } from '../../store/gameStore';
import { tracks } from '../../data/tracks';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Stat from '../ui/Stat';

const TrackSelectScreen: React.FC = () => {
  const { setScreen, selectTrack, selectedTrack, startGame } = useGameStore();
  const [selectedTrackIndex, setSelectedTrackIndex] = useState(
    selectedTrack ? tracks.findIndex(track => track.id === selectedTrack.id) : 0
  );

  const handleSelectTrack = (index: number) => {
    setSelectedTrackIndex(index);
    selectTrack(tracks[index]);
  };

  const handleStartRace = () => {
    if (selectedTrack) {
      startGame();
    }
  };

  const getDifficultyLevel = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 33;
      case 'medium':
        return 66;
      case 'hard':
        return 100;
      default:
        return 0;
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-gradient-to-b from-gray-900 to-gray-800 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setScreen('garage')}
            className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 text-white transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-bold text-white">Select Track</h1>
        </div>
        <Button 
          onClick={handleStartRace} 
          disabled={!selectedTrack} 
          variant="primary"
        >
          Start Race
        </Button>
      </div>

      {/* Main content */}
      <div className="flex flex-col md:flex-row h-full overflow-hidden">
        {/* Track preview */}
        <div className="w-full md:w-2/3 h-1/2 md:h-full flex items-center justify-center p-6 relative">
          {tracks[selectedTrackIndex] && (
            <div className="w-full h-full flex flex-col items-center">
              <h2 className="text-3xl font-bold text-white mb-2">
                {tracks[selectedTrackIndex].name}
              </h2>
              <p className="text-gray-400 mb-6">{tracks[selectedTrackIndex].scenery} • {tracks[selectedTrackIndex].weather}</p>
              
              <div className="relative w-full h-64 md:h-80 overflow-hidden rounded-xl mb-6 transform transition-transform duration-500">
                <img
                  src={tracks[selectedTrackIndex].thumbnail}
                  alt={tracks[selectedTrackIndex].name}
                  className="w-full h-full object-cover object-center transform hover:scale-110 transition-transform duration-1000"
                />
                <div 
                  className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"
                ></div>
              </div>
              
              <div className="grid grid-cols-2 gap-6 w-full max-w-lg">
                <Stat
                  label="DIFFICULTY"
                  value={tracks[selectedTrackIndex].difficulty.toUpperCase()}
                  max={100}
                  color={
                    tracks[selectedTrackIndex].difficulty === 'easy' 
                      ? 'green' 
                      : tracks[selectedTrackIndex].difficulty === 'medium' 
                        ? 'yellow' 
                        : 'red'
                  }
                  icon={<Thermometer size={16} />}
                />
                <Stat
                  label="TRACK LENGTH"
                  value={`${tracks[selectedTrackIndex].length} km`}
                  icon={<RoadMap size={16} />}
                />
              </div>
            </div>
          )}
        </div>

        {/* Track selection */}
        <div className="w-full md:w-1/3 h-1/2 md:h-full flex flex-col p-6 overflow-y-auto bg-gray-900 bg-opacity-50">
          <h3 className="text-white text-xl font-bold mb-4">Available Tracks</h3>
          <div className="grid grid-cols-1 gap-4">
            {tracks.map((track, index) => (
              <Card
                key={track.id}
                onClick={() => handleSelectTrack(index)}
                selected={selectedTrackIndex === index}
              >
                <div className="flex items-center p-4">
                  <div className="w-16 h-16 rounded-lg overflow-hidden mr-4 flex-shrink-0">
                    <img
                      src={track.thumbnail}
                      alt={track.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-bold">{track.name}</h4>
                    <p className="text-gray-400 text-sm">{track.weather} • {track.length} km</p>
                    <div className="w-full h-1 bg-gray-700 rounded-full overflow-hidden mt-2">
                      <div 
                        className={`h-full ${
                          track.difficulty === 'easy'
                            ? 'bg-green-500'
                            : track.difficulty === 'medium'
                              ? 'bg-yellow-500'
                              : 'bg-red-500'
                        }`}
                        style={{ width: `${getDifficultyLevel(track.difficulty)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackSelectScreen;