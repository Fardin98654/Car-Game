import React, { useState, useEffect } from 'react';

interface CountdownTimerProps {
  seconds: number;
  onComplete: () => void;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ seconds, onComplete }) => {
  const [countdown, setCountdown] = useState(seconds);
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => {
        setIsAnimating(false);
        setTimeout(() => {
          setCountdown(countdown - 1);
          setIsAnimating(true);
        }, 200);
      }, 800);

      return () => clearTimeout(timer);
    } else {
      // Countdown finished, trigger complete action
      onComplete();
    }
  }, [countdown, onComplete]);

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 backdrop-blur-sm z-40">
      {countdown > 0 ? (
        <div className={`relative ${isAnimating ? 'scale-100 opacity-100' : 'scale-150 opacity-0'} transition-all duration-200`}>
          <div className="text-9xl font-bold text-white">{countdown}</div>
          <div className="absolute inset-0 animate-ping-slow opacity-30 text-9xl font-bold text-white flex items-center justify-center">
            {countdown}
          </div>
          <div className="text-2xl text-center text-gray-200 mt-4">GET READY</div>
        </div>
      ) : (
        <div className="flex flex-col items-center">
          <div className="text-7xl font-bold text-green-500 animate-bounce">GO!</div>
          <div className="w-40 h-1 bg-green-500 mt-4 animate-pulse"></div>
        </div>
      )}
    </div>
  );
};

export default CountdownTimer;