import React, { useState, useEffect } from 'react';
import { Clock, Flag, Trophy, Gauge, Zap, AlertTriangle, MapPin } from 'lucide-react';
import { ControlsState } from '../../utils/controls';
import { formatTime } from '../../utils/helpers';

interface HUDProps {
  speed: number;
  currentLap: number;
  totalLaps: number;
  raceTime: number;
  position: number;
  controls: ControlsState;
}

const HUD: React.FC<HUDProps> = ({
  speed,
  currentLap,
  totalLaps,
  raceTime,
  position,
  controls
}) => {
  const [showWarning, setShowWarning] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');
  const [nitroLevel, setNitroLevel] = useState(100);
  const [isUsingNitro, setIsUsingNitro] = useState(false);

  // Simulate nitro usage when nitro control is active
  useEffect(() => {
    if (controls.nitro && nitroLevel > 0) {
      setIsUsingNitro(true);
      const interval = setInterval(() => {
        setNitroLevel(prev => Math.max(0, prev - 2));
      }, 100);
      
      return () => clearInterval(interval);
    } else {
      setIsUsingNitro(false);
      
      if (nitroLevel < 100) {
        const regenInterval = setInterval(() => {
          setNitroLevel(prev => Math.min(100, prev + 0.5));
        }, 100);
        
        return () => clearInterval(regenInterval);
      }
    }
  }, [controls.nitro, nitroLevel]);

  // Demonstrate a warning (would be triggered by game events)
  useEffect(() => {
    const showRandomWarning = () => {
      const warnings = ['Off-track warning!', 'Collision imminent!', 'Sharp turn ahead!'];
      const randomIndex = Math.floor(Math.random() * warnings.length);
      
      setWarningMessage(warnings[randomIndex]);
      setShowWarning(true);
      
      setTimeout(() => {
        setShowWarning(false);
      }, 3000);
    };
    
    // For demo purposes only - would be triggered by actual game events
    const warningTimer = setTimeout(showRandomWarning, 5000);
    
    return () => clearTimeout(warningTimer);
  }, []);

  // Calculate speedometer angle based on speed
  const getSpeedometerAngle = () => {
    const maxSpeed = 300; // Max speed in km/h
    const maxAngle = 180; // Semicircle
    
    return (speed / maxSpeed) * maxAngle;
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none">
      {/* Top Status Bar */}
      <div className="flex justify-between items-center bg-black bg-opacity-50 backdrop-blur-sm p-3 text-white">
        <div className="flex items-center space-x-6">
          <div className="flex items-center">
            <Flag size={16} className="mr-2 text-white" />
            <span className="font-medium">Lap {currentLap}/{totalLaps}</span>
          </div>
          <div className="flex items-center">
            <Clock size={16} className="mr-2 text-white" />
            <span className="font-mono">{formatTime(raceTime)}</span>
          </div>
        </div>
        <div className="flex items-center">
          <Trophy size={16} className="mr-2 text-yellow-400" />
          <span className="font-medium">{position === 1 ? '1st' : position === 2 ? '2nd' : position === 3 ? '3rd' : `${position}th`} Position</span>
        </div>
      </div>

      {/* Warning Notification */}
      {showWarning && (
        <div className="absolute top-16 left-1/2 transform -translate-x-1/2 bg-red-600 bg-opacity-70 text-white px-4 py-2 rounded-full flex items-center animate-pulse">
          <AlertTriangle size={18} className="mr-2" />
          <span className="font-medium">{warningMessage}</span>
        </div>
      )}

      {/* Speed Display */}
      <div className="absolute bottom-8 left-8 flex flex-col items-center">
        <div className="relative w-36 h-20">
          {/* Speedometer Background */}
          <div className="absolute bottom-0 w-full h-32 bg-black bg-opacity-70 backdrop-blur-sm rounded-t-full overflow-hidden flex items-end justify-center pb-4">
            <div className="relative w-28 h-14 border-t-2 border-l-2 border-r-2 border-gray-600 rounded-t-full">
              {/* Speed Markings */}
              {[0, 30, 60, 90, 120, 150].map((mark, index) => (
                <div 
                  key={mark} 
                  className="absolute bottom-0 w-0.5 h-3 bg-gray-400"
                  style={{ 
                    left: `${index * 20}%`, 
                    transform: `translateX(-50%) rotate(${(index * 30) - 90}deg)`,
                    transformOrigin: 'bottom center' 
                  }}
                />
              ))}
              
              {/* Speed Indicator */}
              <div 
                className="absolute bottom-0 left-1/2 w-1 h-12 bg-red-500"
                style={{ 
                  transform: `translateX(-50%) rotate(${getSpeedometerAngle() - 90}deg)`,
                  transformOrigin: 'bottom center',
                  transition: 'transform 0.2s ease-out'
                }}
              >
                <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-red-500 rounded-full"></div>
              </div>
            </div>
          </div>
          
          {/* Digital Speed Readout */}
          <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-center">
            <div className="text-3xl font-bold text-white font-mono">{Math.round(speed)}</div>
            <div className="text-xs text-gray-300 -mt-1">KM/H</div>
          </div>
        </div>

        {/* RPM Bar */}
        <div className="w-36 h-4 bg-black bg-opacity-70 rounded-lg overflow-hidden mt-2">
          <div 
            className="h-full bg-gradient-to-r from-green-500 via-yellow-500 to-red-500"
            style={{ width: `${(speed / 300) * 100}%`, transition: 'width 0.1s ease-out' }}
          ></div>
        </div>
      </div>

      {/* Nitro Meter */}
      <div className="absolute bottom-8 right-8">
        <div className="flex items-center mb-1">
          <Zap size={16} className={`mr-1 ${isUsingNitro ? 'text-blue-400 animate-pulse' : 'text-gray-400'}`} />
          <span className={`text-sm ${isUsingNitro ? 'text-blue-400' : 'text-gray-400'}`}>NITRO</span>
        </div>
        <div className="w-36 h-6 bg-black bg-opacity-70 backdrop-blur-sm rounded-lg overflow-hidden">
          <div 
            className={`h-full ${isUsingNitro ? 'bg-blue-500' : 'bg-blue-700'} relative`}
            style={{ 
              width: `${nitroLevel}%`,
              transition: 'width 0.1s ease-out',
              boxShadow: isUsingNitro ? '0 0 10px 3px rgba(59, 130, 246, 0.7)' : 'none'
            }}
          >
            {isUsingNitro && (
              <div className="absolute inset-0 bg-blue-400 opacity-30 animate-pulse"></div>
            )}
          </div>
        </div>
      </div>

      {/* Control Indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
        <div className={`w-10 h-10 rounded border-2 ${controls.backward ? 'bg-white bg-opacity-30 border-white' : 'bg-black bg-opacity-50 border-gray-600'} flex items-center justify-center`}>
          <span className="text-white">↓</span>
        </div>
        <div className={`w-10 h-10 rounded border-2 ${controls.left ? 'bg-white bg-opacity-30 border-white' : 'bg-black bg-opacity-50 border-gray-600'} flex items-center justify-center`}>
          <span className="text-white">←</span>
        </div>
        <div className={`w-10 h-10 rounded border-2 ${controls.forward ? 'bg-white bg-opacity-30 border-white' : 'bg-black bg-opacity-50 border-gray-600'} flex items-center justify-center`}>
          <span className="text-white">↑</span>
        </div>
        <div className={`w-10 h-10 rounded border-2 ${controls.right ? 'bg-white bg-opacity-30 border-white' : 'bg-black bg-opacity-50 border-gray-600'} flex items-center justify-center`}>
          <span className="text-white">→</span>
        </div>
        <div className={`w-10 h-10 rounded border-2 ${controls.brake ? 'bg-red-500 bg-opacity-30 border-red-500' : 'bg-black bg-opacity-50 border-gray-600'} flex items-center justify-center`}>
          <span className="text-white">B</span>
        </div>
        <div className={`w-10 h-10 rounded border-2 ${controls.nitro ? 'bg-blue-500 bg-opacity-30 border-blue-500' : 'bg-black bg-opacity-50 border-gray-600'} flex items-center justify-center`}>
          <span className="text-white">N</span>
        </div>
      </div>

      {/* Mini Map (simple placeholder) */}
      <div className="absolute top-16 right-8 w-40 h-40 bg-black bg-opacity-50 backdrop-blur-sm rounded-lg overflow-hidden">
        <div className="absolute inset-2 border border-gray-600 rounded-md">
          {/* Track outline (simplified) */}
          <div className="absolute w-32 h-28 border-4 border-gray-600 rounded-full top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
          
          {/* Player position */}
          <div className="absolute w-3 h-3 bg-red-500 rounded-full" style={{ 
            top: '70%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            boxShadow: '0 0 4px 2px rgba(239, 68, 68, 0.5)'
          }}></div>
          
          {/* Other racers (simplified) */}
          <div className="absolute w-2 h-2 bg-blue-500 rounded-full" style={{ top: '45%', left: '48%' }}></div>
          <div className="absolute w-2 h-2 bg-blue-500 rounded-full" style={{ top: '40%', left: '52%' }}></div>
          <div className="absolute w-2 h-2 bg-blue-500 rounded-full" style={{ top: '35%', left: '48%' }}></div>
          
          {/* Finish Line */}
          <div className="absolute w-8 h-2 bg-white top-1/4 left-1/2 transform -translate-x-1/2"></div>
        </div>
        
        <div className="absolute top-2 left-2 flex items-center">
          <MapPin size={12} className="text-gray-400 mr-1" />
          <span className="text-xs text-gray-400">MAP</span>
        </div>
      </div>
    </div>
  );
};

export default HUD;