import React, { useRef, useEffect, useState } from 'react';
import { useGameStore } from '../../store/gameStore';
import { useControls } from '../../utils/controls';
import { formatTime } from '../../utils/helpers';
import HUD from './HUD';
import GameCanvas from './GameCanvas';
import PauseMenu from './PauseMenu';
import CountdownTimer from './CountdownTimer';

const GameScene: React.FC = () => {
  const { screen, pauseGame, updateTime, raceTime, currentLap, totalLaps, selectedCar, selectedTrack } = useGameStore();
  const controls = useControls();
  const [isRacing, setIsRacing] = useState(false);
  const [isCountdown, setIsCountdown] = useState(true);
  const gameLoopRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  // Game loop
  useEffect(() => {
    if (!isRacing) return;

    const gameLoop = (timestamp: number) => {
      if (!lastTimeRef.current) {
        lastTimeRef.current = timestamp;
      }

      const deltaTime = (timestamp - lastTimeRef.current) / 1000;
      lastTimeRef.current = timestamp;

      // Update race time
      updateTime(raceTime + deltaTime);

      // Schedule next frame
      gameLoopRef.current = requestAnimationFrame(gameLoop);
    };

    gameLoopRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, [isRacing, raceTime, updateTime]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        pauseGame();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [pauseGame]);

  // Handle countdown timer completion
  const handleCountdownComplete = () => {
    setIsCountdown(false);
    setIsRacing(true);
  };

  if (screen === 'pause') {
    return <PauseMenu />;
  }

  return (
    <div className="relative w-full h-full overflow-hidden">
      {/* Game Canvas */}
      <GameCanvas />
      
      {/* HUD */}
      <HUD 
        speed={0} 
        currentLap={currentLap} 
        totalLaps={totalLaps} 
        raceTime={raceTime} 
        position={1} 
        controls={controls}
      />
      
      {/* Countdown */}
      {isCountdown && (
        <CountdownTimer seconds={3} onComplete={handleCountdownComplete} />
      )}
      
      {/* Race Summary (shown when race is completed) */}
      {currentLap > totalLaps && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-70 z-50">
          <div className="bg-gray-900 rounded-xl p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold text-white text-center mb-6">Race Complete!</h2>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Track:</span>
                <span className="text-white font-semibold">{selectedTrack?.name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Car:</span>
                <span className="text-white font-semibold">{selectedCar?.name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Time:</span>
                <span className="text-white font-semibold font-mono">{formatTime(raceTime)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Position:</span>
                <span className="text-white font-semibold">1st</span>
              </div>
            </div>
            
            <div className="mt-8 flex space-x-4">
              <button
                onClick={() => pauseGame()}
                className="flex-1 py-2 px-4 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
              >
                Menu
              </button>
              <button
                onClick={() => {}}
                className="flex-1 py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors"
              >
                Restart
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GameScene;