import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.turbox.racing',
  appName: 'Turbo X Racing',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  android: {
    buildOptions: {
      keystorePath: 'release-key.keystore',
      keystorePassword: 'your-keystore-password',
      keystoreAlias: 'release-key-alias',
      keystoreAliasPassword: 'your-alias-password'
    }
  }
};

export default config;