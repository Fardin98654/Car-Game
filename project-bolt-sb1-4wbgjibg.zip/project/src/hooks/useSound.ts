import { useEffect, useRef } from 'react';
import { Howl } from 'howler';
import { useGameStore } from '../store/gameStore';

type SoundType = 'engine' | 'drift' | 'crash' | 'nitro' | 'win' | 'countdown' | 'menu' | 'select';

export const useSound = () => {
  const isMuted = useGameStore(state => state.isMuted);
  const soundRefs = useRef<Record<SoundType, Howl | null>>({
    engine: null,
    drift: null,
    crash: null,
    nitro: null,
    win: null,
    countdown: null,
    menu: null,
    select: null
  });

  useEffect(() => {
    // Initialize sounds
    soundRefs.current.engine = new Howl({
      src: ['https://assets.codepen.io/21542/howler-demo-bg-music.mp3'], // Placeholder URL
      loop: true,
      volume: 0.5,
      rate: 1.0
    });

    soundRefs.current.drift = new Howl({
      src: ['https://assets.codepen.io/21542/howler-demo-bg-music.mp3'], // Placeholder URL
      volume: 0.3
    });

    soundRefs.current.crash = new Howl({
      src: ['https://assets.codepen.io/21542/howler-demo-bg-music.mp3'], // Placeholder URL
      volume: 0.7
    });

    soundRefs.current.nitro = new Howl({
      src: ['https://assets.codepen.io/21542/howler-demo-bg-music.mp3'], // Placeholder URL
      volume: 0.6
    });

    soundRefs.current.win = new Howl({
      src: ['https://assets.codepen.io/21542/howler-demo-bg-music.mp3'], // Placeholder URL
      volume: 0.8
    });

    soundRefs.current.countdown = new Howl({
      src: ['https://assets.codepen.io/21542/howler-demo-bg-music.mp3'], // Placeholder URL
      volume: 0.8
    });

    soundRefs.current.menu = new Howl({
      src: ['https://assets.codepen.io/21542/howler-demo-bg-music.mp3'], // Placeholder URL
      loop: true,
      volume: 0.3
    });

    soundRefs.current.select = new Howl({
      src: ['https://assets.codepen.io/21542/howler-demo-bg-music.mp3'], // Placeholder URL
      volume: 0.4
    });

    // Start menu music
    if (!isMuted && soundRefs.current.menu) {
      soundRefs.current.menu.play();
    }

    return () => {
      // Stop and unload all sounds
      Object.values(soundRefs.current).forEach(sound => {
        if (sound) {
          sound.stop();
          sound.unload();
        }
      });
    };
  }, []);

  useEffect(() => {
    // Mute/unmute all sounds
    Object.values(soundRefs.current).forEach(sound => {
      if (sound) {
        sound.mute(isMuted);
      }
    });
  }, [isMuted]);

  const playSound = (type: SoundType, options?: { rate?: number }) => {
    const sound = soundRefs.current[type];
    if (sound && !isMuted) {
      if (options?.rate !== undefined) {
        sound.rate(options.rate);
      }
      sound.play();
    }
  };

  const stopSound = (type: SoundType) => {
    const sound = soundRefs.current[type];
    if (sound) {
      sound.stop();
    }
  };

  const updateEngineSound = (speed: number) => {
    const engine = soundRefs.current.engine;
    if (engine && !isMuted) {
      // Adjust pitch based on speed
      const rate = 0.8 + (speed / 200); // Normalize speed to a reasonable pitch range
      engine.rate(rate);
    }
  };

  return {
    playSound,
    stopSound,
    updateEngineSound
  };
};