import React from 'react';
import { ArrowLeft, Trophy, Car, MapPin, Clock } from 'lucide-react';
import { useGameStore } from '../../store/gameStore';
import Button from '../ui/Button';
import { formatTime } from '../../utils/helpers';

const LeaderboardScreen: React.FC = () => {
  const { leaderboard, setScreen } = useGameStore();

  return (
    <div className="relative w-full h-full flex flex-col bg-gradient-to-b from-gray-900 to-gray-800 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setScreen('menu')}
            className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 text-white transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-bold text-white">Leaderboard</h1>
        </div>
      </div>

      {/* Leaderboard content */}
      <div className="flex-1 p-6 overflow-y-auto">
        <div className="max-w-4xl mx-auto bg-gray-800 bg-opacity-50 rounded-xl overflow-hidden backdrop-blur-sm">
          <div className="p-4 bg-indigo-600 text-white flex items-center space-x-2">
            <Trophy size={20} />
            <span className="font-bold">Top Racers</span>
          </div>
          
          {/* Table header */}
          <div className="grid grid-cols-12 gap-4 p-4 border-b border-gray-700 text-gray-400 text-sm font-medium">
            <div className="col-span-1 flex items-center justify-center">#</div>
            <div className="col-span-3 flex items-center">
              <span>Player</span>
            </div>
            <div className="col-span-2 flex items-center">
              <Car size={16} className="mr-2" />
              <span>Car</span>
            </div>
            <div className="col-span-3 flex items-center">
              <MapPin size={16} className="mr-2" />
              <span>Track</span>
            </div>
            <div className="col-span-2 flex items-center">
              <Clock size={16} className="mr-2" />
              <span>Time</span>
            </div>
            <div className="col-span-1 flex items-center justify-center">Date</div>
          </div>
          
          {/* Table body */}
          {leaderboard.map((entry, index) => (
            <div 
              key={`${entry.playerName}-${index}`}
              className={`grid grid-cols-12 gap-4 p-4 text-white border-b border-gray-700 ${
                index === 0 
                  ? 'bg-gradient-to-r from-yellow-500/20 to-transparent' 
                  : index === 1 
                    ? 'bg-gradient-to-r from-gray-400/20 to-transparent'
                    : index === 2 
                      ? 'bg-gradient-to-r from-amber-600/20 to-transparent'
                      : ''
              } hover:bg-gray-700/50 transition-colors`}
            >
              <div className="col-span-1 flex items-center justify-center">
                {index === 0 ? (
                  <div className="w-6 h-6 rounded-full bg-yellow-500 flex items-center justify-center text-black font-bold">1</div>
                ) : index === 1 ? (
                  <div className="w-6 h-6 rounded-full bg-gray-400 flex items-center justify-center text-black font-bold">2</div>
                ) : index === 2 ? (
                  <div className="w-6 h-6 rounded-full bg-amber-600 flex items-center justify-center text-black font-bold">3</div>
                ) : (
                  <div className="w-6 h-6 rounded-full bg-gray-700 flex items-center justify-center font-bold">{index + 1}</div>
                )}
              </div>
              <div className="col-span-3 flex items-center font-semibold">
                {entry.playerName}
              </div>
              <div className="col-span-2 flex items-center text-gray-300">
                {entry.car}
              </div>
              <div className="col-span-3 flex items-center text-gray-300">
                {entry.track}
              </div>
              <div className="col-span-2 flex items-center font-mono font-semibold">
                {formatTime(entry.time)}
              </div>
              <div className="col-span-1 flex items-center justify-center text-xs text-gray-400">
                {entry.date}
              </div>
            </div>
          ))}
          
          {leaderboard.length === 0 && (
            <div className="p-8 text-center text-gray-400">
              <p>No race records yet.</p>
              <p className="mt-2">Complete a race to appear on the leaderboard!</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Footer */}
      <div className="p-6 border-t border-gray-700 flex justify-center">
        <Button
          onClick={() => setScreen('garage')}
          variant="primary"
        >
          Start Racing
        </Button>
      </div>
    </div>
  );
};

export default LeaderboardScreen;