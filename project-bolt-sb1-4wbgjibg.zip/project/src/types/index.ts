export interface Car {
  id: string;
  name: string;
  model: string;
  speed: number;
  acceleration: number;
  handling: number;
  color: string;
  thumbnail: string;
}

export interface Track {
  id: string;
  name: string;
  thumbnail: string;
  difficulty: 'easy' | 'medium' | 'hard';
  length: number;
  scenery: string;
  weather: 'sunny' | 'rainy' | 'foggy' | 'night';
}

export interface GameState {
  screen: 'menu' | 'garage' | 'trackSelect' | 'game' | 'leaderboard' | 'pause';
  selectedCar: Car | null;
  selectedTrack: Track | null;
  isPlaying: boolean;
  currentLap: number;
  totalLaps: number;
  raceTime: number;
  bestLap: number;
  position: number;
  speed: number;
  isMuted: boolean;
}

export interface LeaderboardEntry {
  playerName: string;
  car: string;
  track: string;
  time: number;
  date: string;
}