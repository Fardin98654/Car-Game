import React from 'react';

interface CardProps {
  children: React.ReactNode;
  onClick?: () => void;
  selected?: boolean;
  className?: string;
  hoverEffect?: boolean;
}

const Card: React.FC<CardProps> = ({
  children,
  onClick,
  selected = false,
  className = '',
  hoverEffect = true
}) => {
  const baseStyle = 'relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl shadow-xl overflow-hidden';
  const clickableStyle = onClick ? 'cursor-pointer transition-all duration-300 ease-in-out' : '';
  const hoverStyle = hoverEffect && onClick ? 'hover:scale-105 hover:shadow-2xl' : '';
  const selectedStyle = selected ? 'ring-2 ring-offset-2 ring-offset-gray-800 ring-indigo-500 scale-105' : '';
  
  return (
    <div
      className={`${baseStyle} ${clickableStyle} ${hoverStyle} ${selectedStyle} ${className}`}
      onClick={onClick}
    >
      {children}
      {onClick && (
        <div className="absolute inset-0 bg-indigo-500 opacity-0 transition-opacity duration-200 hover:opacity-10"></div>
      )}
    </div>
  );
};

export default Card;