import React from 'react';
import { Play, Home, RotateCcw, Settings, Volume2, VolumeX } from 'lucide-react';
import { useGameStore } from '../../store/gameStore';
import Button from '../ui/Button';

const PauseMenu: React.FC = () => {
  const { resumeGame, setScreen, isMuted, toggleMute } = useGameStore();

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-70 backdrop-blur-md z-50">
      <div className="bg-gray-900 rounded-2xl p-8 max-w-md w-full border border-gray-700 shadow-2xl">
        <h2 className="text-3xl font-bold text-center text-white mb-8">PAUSED</h2>
        
        <div className="space-y-4">
          <Button
            onClick={resumeGame}
            variant="primary"
            size="lg"
            fullWidth
            icon={<Play size={20} />}
          >
            Resume Race
          </Button>
          
          <Button
            onClick={() => {}}
            variant="secondary"
            size="lg"
            fullWidth
            icon={<RotateCcw size={20} />}
          >
            Restart Race
          </Button>
          
          <div className="flex space-x-4">
            <Button
              onClick={() => setScreen('menu')}
              variant="outline"
              size="lg"
              fullWidth
              icon={<Home size={20} />}
            >
              Main Menu
            </Button>
            
            <Button
              onClick={() => {}}
              variant="outline"
              size="lg"
              fullWidth
              icon={<Settings size={20} />}
            >
              Settings
            </Button>
          </div>
        </div>
        
        <div className="mt-8 flex justify-center">
          <button
            onClick={toggleMute}
            className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors"
          >
            {isMuted ? (
              <>
                <VolumeX size={20} />
                <span>Unmute</span>
              </>
            ) : (
              <>
                <Volume2 size={20} />
                <span>Mute</span>
              </>
            )}
          </button>
        </div>
        
        <div className="mt-6 text-center text-gray-500 text-sm">
          Press ESC to resume
        </div>
      </div>
    </div>
  );
};

export default PauseMenu;