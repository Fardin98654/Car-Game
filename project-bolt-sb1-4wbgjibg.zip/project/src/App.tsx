import React from 'react';
import { useGameStore } from './store/gameStore';
import MainMenu from './components/screens/MainMenu';
import GarageScreen from './components/screens/GarageScreen';
import TrackSelectScreen from './components/screens/TrackSelectScreen';
import LeaderboardScreen from './components/screens/LeaderboardScreen';
import GameScene from './components/game/GameScene';

function App() {
  const { screen } = useGameStore();

  const renderScreen = () => {
    switch (screen) {
      case 'menu':
        return <MainMenu />;
      case 'garage':
        return <GarageScreen />;
      case 'trackSelect':
        return <TrackSelectScreen />;
      case 'game':
        return <GameScene />;
      case 'leaderboard':
        return <LeaderboardScreen />;
      case 'pause':
        return <GameScene />;
      default:
        return <MainMenu />;
    }
  };

  return (
    <div className="w-full h-full">
      {renderScreen()}
    </div>
  );
}

export default App;