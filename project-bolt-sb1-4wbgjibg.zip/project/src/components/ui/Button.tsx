import React from 'react';

interface ButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'accent' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  fullWidth?: boolean;
  className?: string;
  icon?: React.ReactNode;
}

const Button: React.FC<ButtonProps> = ({
  onClick,
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  className = '',
  icon
}) => {
  const baseStyle = 'relative font-semibold rounded-lg transition-all duration-200 ease-in-out transform hover:scale-105 active:scale-95 flex items-center justify-center';
  
  const variantStyles = {
    primary: 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg hover:shadow-indigo-500/50',
    secondary: 'bg-purple-600 text-white hover:bg-purple-700 shadow-lg hover:shadow-purple-500/50',
    accent: 'bg-pink-600 text-white hover:bg-pink-700 shadow-lg hover:shadow-pink-500/50',
    outline: 'bg-transparent border-2 border-indigo-500 text-indigo-500 hover:bg-indigo-500 hover:text-white'
  };
  
  const sizeStyles = {
    sm: 'text-xs py-1 px-3',
    md: 'text-sm py-2 px-4',
    lg: 'text-base py-3 px-6'
  };
  
  const widthStyle = fullWidth ? 'w-full' : '';
  const disabledStyle = disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer';
  
  const buttonClass = `
    ${baseStyle} 
    ${variantStyles[variant]} 
    ${sizeStyles[size]} 
    ${widthStyle} 
    ${disabledStyle}
    ${className}
  `;
  
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={buttonClass}
    >
      {icon && <span className="mr-2">{icon}</span>}
      {children}
      <div className="absolute inset-0 bg-white opacity-0 rounded-lg hover:opacity-10"></div>
    </button>
  );
};

export default Button;