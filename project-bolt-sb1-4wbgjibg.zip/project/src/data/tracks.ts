import { Track } from '../types';

export const tracks: Track[] = [
  {
    id: 'track-1',
    name: 'Coastal Circuit',
    thumbnail: 'https://images.pexels.com/photos/2526128/pexels-photo-2526128.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    difficulty: 'easy',
    length: 3.2,
    scenery: 'coastal',
    weather: 'sunny'
  },
  {
    id: 'track-2',
    name: 'Mountain Pass',
    thumbnail: 'https://images.pexels.com/photos/1032650/pexels-photo-1032650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    difficulty: 'medium',
    length: 4.5,
    scenery: 'mountain',
    weather: 'foggy'
  },
  {
    id: 'track-3',
    name: 'Urban Speedway',
    thumbnail: 'https://images.pexels.com/photos/1707820/pexels-photo-1707820.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    difficulty: 'medium',
    length: 5.1,
    scenery: 'city',
    weather: 'night'
  },
  {
    id: 'track-4',
    name: 'Extreme Rally',
    thumbnail: 'https://images.pexels.com/photos/6081579/pexels-photo-6081579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    difficulty: 'hard',
    length: 6.7,
    scenery: 'off-road',
    weather: 'rainy'
  }
];