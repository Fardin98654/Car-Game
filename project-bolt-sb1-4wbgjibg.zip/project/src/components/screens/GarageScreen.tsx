import React, { useState } from 'react';
import { ArrowLeft, Gauge, Star, Zap, CornerRightDown } from 'lucide-react';
import { useGameStore } from '../../store/gameStore';
import { cars } from '../../data/cars';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Stat from '../ui/Stat';

const GarageScreen: React.FC = () => {
  const { setScreen, selectCar, selectedCar } = useGameStore();
  const [selectedCarIndex, setSelectedCarIndex] = useState(
    selectedCar ? cars.findIndex(car => car.id === selectedCar.id) : 0
  );

  const handleSelectCar = (index: number) => {
    setSelectedCarIndex(index);
    selectCar(cars[index]);
  };

  const handleContinue = () => {
    if (selectedCar) {
      setScreen('trackSelect');
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-gradient-to-b from-gray-900 to-gray-800 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setScreen('menu')}
            className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 text-white transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-bold text-white">Select Your Car</h1>
        </div>
        <Button onClick={handleContinue} disabled={!selectedCar} variant="primary">
          Continue
        </Button>
      </div>

      {/* Main content */}
      <div className="flex flex-col md:flex-row h-full overflow-hidden">
        {/* Car preview */}
        <div className="w-full md:w-2/3 h-1/2 md:h-full flex items-center justify-center p-6 relative">
          {cars[selectedCarIndex] && (
            <div className="w-full h-full flex flex-col items-center">
              <h2 className="text-3xl font-bold text-white mb-2">
                {cars[selectedCarIndex].name}
              </h2>
              <p className="text-gray-400 mb-6">{cars[selectedCarIndex].model}</p>
              
              <div className="relative w-full h-64 md:h-80 overflow-hidden rounded-xl mb-6 transform transition-transform duration-500">
                <img
                  src={cars[selectedCarIndex].thumbnail}
                  alt={cars[selectedCarIndex].name}
                  className="w-full h-full object-cover object-center transform hover:scale-110 transition-transform duration-1000"
                />
                <div 
                  className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"
                ></div>
              </div>
              
              <div className="grid grid-cols-3 gap-6 w-full max-w-lg">
                <Stat
                  label="SPEED"
                  value={cars[selectedCarIndex].speed}
                  max={100}
                  color="blue"
                  icon={<Gauge size={16} />}
                />
                <Stat
                  label="ACCELERATION"
                  value={cars[selectedCarIndex].acceleration}
                  max={100}
                  color="pink"
                  icon={<Zap size={16} />}
                />
                <Stat
                  label="HANDLING"
                  value={cars[selectedCarIndex].handling}
                  max={100}
                  color="purple"
                  icon={<CornerRightDown size={16} />}
                />
              </div>
            </div>
          )}
        </div>

        {/* Car selection */}
        <div className="w-full md:w-1/3 h-1/2 md:h-full flex flex-col p-6 overflow-y-auto bg-gray-900 bg-opacity-50">
          <h3 className="text-white text-xl font-bold mb-4">Available Cars</h3>
          <div className="grid grid-cols-1 gap-4">
            {cars.map((car, index) => (
              <Card
                key={car.id}
                onClick={() => handleSelectCar(index)}
                selected={selectedCarIndex === index}
              >
                <div className="flex items-center p-4">
                  <div 
                    className="w-16 h-16 rounded-lg overflow-hidden mr-4 flex-shrink-0"
                    style={{ backgroundColor: car.color }}
                  >
                    <img
                      src={car.thumbnail}
                      alt={car.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-bold">{car.name}</h4>
                    <p className="text-gray-400 text-sm">{car.model}</p>
                    <div className="flex items-center mt-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          size={12}
                          className={`${
                            i < Math.floor(car.speed / 20)
                              ? 'text-yellow-400 fill-yellow-400'
                              : 'text-gray-600'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GarageScreen;