import React from 'react';
import { Trophy, Car, MapPin, Settings, Volume2, VolumeX } from 'lucide-react';
import { useGameStore } from '../../store/gameStore';
import Button from '../ui/Button';

const MainMenu: React.FC = () => {
  const { setScreen, toggleMute, isMuted } = useGameStore();

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-gradient-to-b from-gray-900 via-blue-900 to-black overflow-hidden">
      {/* Background animation */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full">
          {Array.from({ length: 100 }).map((_, i) => (
            <div
              key={i}
              className="absolute bg-blue-500 opacity-10 rounded-full"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 4 + 1}px`,
                height: `${Math.random() * 4 + 1}px`,
                boxShadow: '0 0 20px 2px rgba(66, 135, 245, 0.5)',
                animation: `moveParticle ${Math.random() * 10 + 20}s linear infinite`
              }}
            ></div>
          ))}
        </div>
      </div>

      {/* Game title */}
      <div className="relative mb-16 text-center">
        <h1 className="text-6xl sm:text-7xl md:text-8xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-500 to-purple-600 mb-2">
          TURBO <span className="text-pink-500">X</span>
        </h1>
        <p className="text-xl text-gray-300 tracking-wider">
          ULTIMATE RACING EXPERIENCE
        </p>
      </div>

      {/* Menu buttons */}
      <div className="relative flex flex-col space-y-4 w-64 z-10">
        <Button 
          onClick={() => setScreen('garage')} 
          variant="primary" 
          size="lg" 
          fullWidth
          icon={<Car size={20} />}
        >
          Start Race
        </Button>
        <Button 
          onClick={() => setScreen('leaderboard')} 
          variant="secondary" 
          size="lg" 
          fullWidth
          icon={<Trophy size={20} />}
        >
          Leaderboard
        </Button>
        <Button 
          onClick={() => setScreen('trackSelect')} 
          variant="accent" 
          size="lg" 
          fullWidth
          icon={<MapPin size={20} />}
        >
          Tracks
        </Button>
        <Button 
          onClick={() => {}} 
          variant="outline" 
          size="lg" 
          fullWidth
          icon={<Settings size={20} />}
        >
          Settings
        </Button>
      </div>

      {/* Mute button */}
      <div className="absolute top-4 right-4">
        <button 
          onClick={toggleMute}
          className="p-2 rounded-full bg-gray-800 hover:bg-gray-700 text-white transition-colors"
        >
          {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
        </button>
      </div>

      {/* Footer */}
      <div className="absolute bottom-4 text-gray-400 text-sm">
        © 2025 Turbo X Racing | v1.0.0
      </div>
    </div>
  );
};

export default MainMenu;